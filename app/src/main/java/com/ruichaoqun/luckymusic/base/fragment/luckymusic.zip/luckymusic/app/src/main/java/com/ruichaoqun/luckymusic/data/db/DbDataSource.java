package com.ruichaoqun.luckymusic.data.db;

/**
 * @author Rui Chaoqun
 * @date :2019/11/28 11:33
 * description:
 */
public interface DbDataSource {
}
