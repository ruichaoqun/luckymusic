package com.ruichaoqun.luckymusic.data.db;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * @author Rui Chaoqun
 * @date :2019/11/28 11:47
 * description:
 */
@Singleton
public class DbDataSourceImpl implements DbDataSource{

    @Inject
    public DbDataSourceImpl() {

    }
}
