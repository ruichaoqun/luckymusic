package com.ruichaoqun.luckymusic.data.preference;

/**
 * @author Rui Chaoqun
 * @date :2019/11/28 11:34
 * description:
 */
public interface PreferenceDataSource {

    void isFirstUse();

    void setFirstUse();
}
