package com.ruichaoqun.luckymusic.service;

/**
 * @author Rui Chaoqun
 * @date :2019/10/12 15:39
 * description:
 */
public class ServiceConst {
    public static final String THEME_SERVICE = "theme";
}
