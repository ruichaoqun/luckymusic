package com.ruichaoqun.luckymusic.theme.impl;

/**
 * @author Rui Chaoqun
 * @date :2019/10/12 11:51
 * description:
 */
public interface OnThemeResetListener {
    void onThemeReset();
}
