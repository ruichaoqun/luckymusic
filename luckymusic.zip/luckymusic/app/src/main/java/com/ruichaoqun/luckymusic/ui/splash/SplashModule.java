package com.ruichaoqun.luckymusic.ui.splash;

import dagger.Module;

@Module
public class SplashModule {
}
