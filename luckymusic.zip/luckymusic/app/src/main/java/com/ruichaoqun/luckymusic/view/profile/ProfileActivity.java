package com.ruichaoqun.luckymusic.view.profile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ruichaoqun.luckymusic.R;
import com.ruichaoqun.luckymusic.basic.BaseToolBarActivity;

public class ProfileActivity extends BaseToolBarActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
